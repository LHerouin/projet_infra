const http = require('http');
exports.curl = (req, res) => {
  
  const options = {
  hostname: '34.136.213.223',
  port:80,
  path: '/',
  method: 'GET',
  agent: false
  };

  const req1 = http.request(options, (res) => {
  });
  let message = req.query.message || req.body.message || req1;
  res.status(200).send(message);
};